---------------------------------------------------------------------------
-- Service Checklist Widget
-- EdgeTX 2.11+
-- Date-based service tracking with GV7 flags
---------------------------------------------------------------------------

local name = "serviceList"

local previousLastService = nil
local messageTimer = 0
local messageText1 = ""
local messageText2 = ""
local messageColor = GREEN
local MESSAGE_DURATION = 300  -- 3 seconds


---------------------------------------------------------------------------
-- PREDEFINED CHECKLIST TEXT
---------------------------------------------------------------------------

local checklistText = {
  -- SAFETY CHECKS LIST
  "Antenna Secure","Battery Secured","Failsafe Test","Gyro Direction","CG Check",
  "Canopy Secure","Hatch Secure","Wires Clear","No Loose Parts","No Damage",
  "Motor Secure","Prop Tight","Prop Undamaged","Gear Mesh","Pinion Tight",
  "Main Gear","Ailerons Secure","Elevator Secure","Rudder Secure","Mechanical Travel",
  "Servo Secure","Servo Arms","Linkages Tight","Hinges Secure","Control Horns",
  "Tail Check","Swash Level","Pitch Direction","Blade Grip OK","Main Blades",
  "Blade Tracking","One Way Bearing","Tail Slider Smooth",
  "Tail Belt","Tail Gear","Main Shaft","Landing Gear","Wheels Secure",
  "Struts","Skids Secure","RX Antennas",

  -- SERVICE LIST
  "Airframe Clean","Frame Cracks","Fasteners Tight","Threadlock","Structure",
  "Surface Alignment","Hinges Free","Linkage Slop","Pushrods Straight","Clevises Secure",
  "Ball Links Free","Control Horns","Servo Mounts","Wing Mounts","Wing Bolts","Wing Joiner",
  "Motor Mount","Firewall","Motor Bearings","Prop Condition","Prop Balanced",
  "Tail Blades","Blade Grip","Main Blades","Blade Bolts","Main Shaft","Screws Secure",
  "Feathering Shaft","Head Dampers","Swash Bearings","Gear Condition","Pinion Condition",
  "Gear Mesh","One-Way Bearing","Other Bearings","Anti-Rotation","Tail Mechanism",
  "Tail Bearings","Torque Tube","Tail Belt","Tail Slider","Landing Gear",
  "Skids Secure","Wheels Secure","Vibration Check","Wiring Secure",
  "Cable Chafing","Connectors Secure", "Boom State"
}

local MAX_ITEMS      = #checklistText
local PARAM_COUNT    = 4
local MAX_PER_COLUMN = 8

---------------------------------------------------------------------------
-- WIDGET OPTIONS
---------------------------------------------------------------------------

local options = {
  { "P1", STRING, "" },
  { "P2", STRING, "" },
  { "P3", STRING, "" },
  { "P4", STRING, "" },

  { "Mode", VALUE, 0, 0, 1 },            -- 0 = Date, 1 = Flight count
  { "Last Service", STRING, "" },        -- Date or flight count
  { "Interval", VALUE, 30, 1, 365 },    -- Days or flights
  { "Flight Counter", SOURCE, 0 },       -- GV / counter source
  { "GV7", VALUE, 0, 0, 1 },              -- Enable GV7 output
}

---------------------------------------------------------------------------
-- HELPER FUNCTIONS
---------------------------------------------------------------------------

local function parseNumbers(str, out)
  if type(str) ~= "string" then return end
  for n in string.gmatch(str, "%d+") do
    local v = tonumber(n)
    if v and v >= 1 and v <= MAX_ITEMS then
      out[#out + 1] = v
    end
  end
end

local function parseDate(str)
  if type(str) ~= "string" then return nil end
  local d,m,y = string.match(str,"(%d%d)/(%d%d)/(%d%d%d%d)")
  d,m,y = tonumber(d),tonumber(m),tonumber(y)
  if not d or not m or not y then return nil end
  return { day=d, month=m, year=y }
end

local daysInMonth = {31,28,31,30,31,30,31,31,30,31,30,31}

local function isLeapYear(y)
  return (y%4==0 and y%100~=0) or (y%400==0)
end

local function addDays(date, days)
  local d,m,y = date.day,date.month,date.year
  while days > 0 do
    local dim = daysInMonth[m]
    if m==2 and isLeapYear(y) then dim=29 end
    if d+days <= dim then
      d=d+days
      days=0
    else
      days = days - (dim-d+1)
      d=1; m=m+1
      if m>12 then m=1; y=y+1 end
    end
  end
  return { day=d, month=m, year=y }
end

local function dateToDays(d)
  local days = d.year*365 + math.floor((d.year+3)/4)
  for i=1,d.month-1 do
    days = days + daysInMonth[i]
    if i==2 and isLeapYear(d.year) then days=days+1 end
  end
  return days + d.day
end

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return { zone=zone, options=opts or {} }
end

local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z = widget.zone
  local opt = widget.options or {}

  lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,COLOR_BLACK)

  local dt = getDateTime()
  local today = { day=dt.day, month=dt.mon, year=dt.year }
  
local mode     = tonumber(opt.Mode) or 0
local interval = tonumber(opt.Interval) or 30

local lastValue
local dueValue
local remaining

-----------------------------------------------------------------------
-- MODE 0 : DATE-BASED (EXISTING BEHAVIOUR)
-----------------------------------------------------------------------
if mode == 0 then
  local lastDate = parseDate(opt["Last Service"])
  if lastDate then
    dueValue  = addDays(lastDate, interval)
    remaining = dateToDays(dueValue) - dateToDays(today)
    lastValue = lastDate
  end
end

-----------------------------------------------------------------------
-- MODE 1 : FLIGHT-BASED
-----------------------------------------------------------------------
if mode == 1 then
  local lastCount = tonumber(opt["Last Service"])
  local src = opt["Flight Counter"]

  if lastCount and src then
    local currentCount = getValue(src)
    if type(currentCount) == "number" then
      dueValue  = lastCount + interval
      remaining = dueValue - currentCount
      lastValue = lastCount
    end
  end
end

--Congratulations logic
-- Only act if the "Last Service" option changed
local newService = opt["Last Service"]
local showMessage = false

if previousLastService == nil then
    previousLastService = newService
end

if newService ~= previousLastService then
    local valid = true
    local enteredDate, enteredCount

    if mode == 0 then
        -- DATE MODE
        enteredDate = parseDate(newService)
        local previousDate = parseDate(previousLastService)

        if not enteredDate then
            valid = false
            messageText1 = "Date Entered"
            messageText2 = "Is Incorrect"
            messageColor = RED
        elseif previousDate and dateToDays(enteredDate) < dateToDays(previousDate) then
            valid = false
            messageText1 = "Date Entered"
            messageText2 = "Is Less Than Previous"
            messageColor = RED
        elseif dateToDays(enteredDate) > dateToDays(today) then
            valid = false
            messageText1 = "Date Entered"
            messageText2 = "Is In The Future"
            messageColor = RED
        end

    elseif mode == 1 then
        -- FLIGHT MODE
        enteredCount = tonumber(newService)
        local previousCount = tonumber(previousLastService)
        local currentCount = getValue(opt["Flight Counter"])

        if not enteredCount then
            valid = false
            messageText1 = "Flight Count"
            messageText2 = "Is Incorrect"
            messageColor = RED
        elseif previousCount and enteredCount < previousCount then
            valid = false
            messageText1 = "Flight Count"
            messageText2 = "Is Less Than Previous"
            messageColor = RED
        elseif currentCount and enteredCount > currentCount then
            valid = false
            messageText1 = "Flight Count"
            messageText2 = "Is In The Future"
            messageColor = RED
        end
    end

    if valid then
        messageText1 = "Congratulations!"
        messageText2 = "Service Complete"
        messageColor = GREEN
    end

    previousLastService = newService
    messageTimer = getTime()  -- start the timer
end

-- Display message if within duration
if getTime() - messageTimer <= MESSAGE_DURATION then
    lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, COLOR_BLACK)
    lcd.drawText(z.x + z.w/2, z.y + z.h/2 - 25, messageText1, CENTER + DBLSIZE + messageColor)
    lcd.drawText(z.x + z.w/2, z.y + z.h/2 + 10, messageText2, CENTER + DBLSIZE + messageColor)
    return -- skip the rest while message is active
end



  local overdue = remaining and remaining <= 0
  local flashOn = (getTime()%100) < 50

  -- TITLE
 if remaining and overdue then
   if flashOn then 
     lcd.drawText( z.x + z.w / 2, z.y + 14, "SERVICE DUE", CENTER + DBLSIZE + RED ) 
  end 
  else -- Not overdue or no date: SERVICE CHECKLIST 
    lcd.drawText( z.x + z.w / 2, z.y + 14, "SERVICE CHECKLIST", CENTER + DBLSIZE + WHITE ) 
  end

  -- CHECKLIST
  local leftMargin = z.x+10
  local colW = 150
  local colGap = 5
  local colX = { leftMargin, leftMargin+colW+colGap }
  local startY = z.y+65
  local lineH = 20

  local items={}
  for i=1,PARAM_COUNT do parseNumbers(opt["P"..i],items) end

  for i=1,math.min(#items,MAX_PER_COLUMN*2) do
    local c = (i<=MAX_PER_COLUMN) and 1 or 2
    local r = (i-1)%MAX_PER_COLUMN
    lcd.drawText(colX[c], startY+r*lineH, checklistText[items[i]], WHITE)
  end


-- SERVICE INFO (DATE OR FLIGHT MODE)
local serviceY = z.y + z.h - 30

if remaining then
  if mode == 0 then
    -- DATE MODE
    lcd.drawText(z.x + 10, serviceY,
      string.format("Last Service: %02d/%02d/%04d",
        lastValue.day, lastValue.month, lastValue.year),
      overdue and RED or GREEN)

    lcd.drawText(z.x + z.w - 10, serviceY,
      string.format("Service Due: %02d/%02d/%04d",
        dueValue.day, dueValue.month, dueValue.year),
      RIGHT + (overdue and RED or GREEN))
  else
    -- FLIGHT MODE
    lcd.drawText(z.x + 10, serviceY,
      string.format("Last Flight Service: %d", lastValue),
      overdue and RED or GREEN)

    lcd.drawText(z.x + z.w - 10, serviceY,
      string.format("Service Due: Flight #%d", dueValue),
      RIGHT + (overdue and RED or GREEN))
  end
else
  lcd.drawText(
    z.x + z.w / 2,
    serviceY,
    (mode == 0)
      and "ENTER LAST SERVICE DATE (DD/MM/YYYY)"
      or  "ENTER LAST SERVICE FLIGHT COUNT",
    CENTER + YELLOW
  )
end


  -- STATUS CIRCLE
  if remaining then
    local rightStart = leftMargin + colW*2 + colGap + 10
    local availW = z.x+z.w - rightStart - 10
    local topY = z.y+45
    local botY = serviceY - 10
    local availH = botY - topY
    local r = math.floor(math.min(availW,availH)/2)

    local cx = rightStart + availW/2
    local cy = topY + availH/2

    local fill =
      (remaining <= 3)  and RED or
      (remaining <= 10) and YELLOW or GREEN

    lcd.drawFilledCircle(cx,cy,r,fill)
    lcd.drawCircle(cx,cy,r,GREY)
    lcd.drawCircle(cx,cy,r-1,GREY)

    local txt = tostring(remaining)
    lcd.drawText(cx, cy - 38, txt, CENTER + DBLSIZE + BOLD + BLACK)
    
    local labelText
    if remaining < 0 then
      labelText = (mode == 0) and "Days overdue" or "Flights overdue"
    else
      labelText = (mode == 0) and "Days till service" or "Flights till service"
    end
    lcd.drawText(cx, cy + r/2 - 5, labelText, CENTER + SMLSIZE + BLACK)
  end

----------------------------------------------------------------------- 
-- WRITE TO GV7 FM0 
----------------------------------------------------------------------- 
local gv7Index = 0  -- FM0
local gv7 = model.getGlobalVariable(6, gv7Index) or 0

if opt.GV7 == 1 then -- i added this value parameter, if 1 i want to use the below logic for gv7 else i dont want to use the log
if remaining then
    if remaining <= 0 then
        -- Overdue
        if gv7 ~= 1 then
            model.setGlobalVariable(6, gv7Index, 1)
            gv7 = 1
        end
    elseif remaining <= 10 then
        -- Approaching service
        if gv7 ~= 2 then
            model.setGlobalVariable(6, gv7Index, 2)
            gv7 = 2
        end
    else
        -- Not due yet
        if gv7 ~= 0 then
            model.setGlobalVariable(6, gv7Index, 0)
            gv7 = 0
        end
    end
end
end

end

---------------------------------------------------------------------------
-- RETURN
---------------------------------------------------------------------------

return {
  name=name,
  create=create,
  update=update,
  refresh=refresh,
  options=options
}
