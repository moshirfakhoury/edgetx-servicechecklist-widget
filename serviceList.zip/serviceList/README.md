Service Checklist Widget for EdgeTX



Overview



The Service Checklist Widget is designed for RC planes, helicopters, and drones to track maintenance schedules and ensure mechanical checks are completed. Using a user-entered Last Service field and Interval, the widget calculates the next service due date / flight and provides an “in-your-face” alert when maintenance is overdue.

When overdue, it sets a global variable (GV7 FM0 = 1), allowing integration with logical switches to trigger special functions like automatic page selection. This ensures critical maintenance reminders are never missed while keeping the widget unobtrusive when everything is up-to-date.

The widget also supports two service tracking modes, allowing maintenance to be scheduled either by calendar date or by flight count, depending on user preference.



Functions

\- Service Tracking (Dual Mode):

&nbsp; - Date Mode (Mode = 0)

&nbsp;   Enter last service date (DD/MM/YYYY) and service interval (days) to calculate the next service due date.

&nbsp; - Flight Count Mode (Mode = 1)

&nbsp;   Enter last service flight number and service interval (flights).

&nbsp;   The widget reads a selected flight counter source (e.g. a Global Variable) to determine when the next service is due.

&nbsp;   

\- Checklist Display:

&nbsp; - Predefined safety and mechanical service items are displayed in two columns.

&nbsp; - There are over 80 checklist items the user can select from.

&nbsp; - The full list is stored in the Widget Checklist Items.txt file and can be viewed directly on the Radiomaster transmitter

&nbsp; - The screen can display up to 16 checks at a time.

\- Overdue Alerts:

&nbsp; - Title flashes red and changes to “SERVICE DUE” when maintenance is overdue.

&nbsp; - Last service and service due values are highlighted in red if overdue, otherwise green.



\- Remaining Counter (Days / Flights):

&nbsp; - A circle on the screen shows the remaining days or flights until the next service, depending on the selected mode.

&nbsp; - The circle color indicates urgency:

&nbsp;   - Green if > 10 remaining

&nbsp;   - Yellow if <= 10 remaining

&nbsp;   - Red if <= 3 remaining

&nbsp; - If overdue, the value becomes negative and the label changes to:

&nbsp;   - “Days overdue” (Date Mode)

&nbsp;   - “Flights overdue” (Flight Mode)

&nbsp;     

\- Global Variable Output:

&nbsp; - Optional GV7 output – can be enabled or disabled via widget options.

&nbsp; - Writes 0 to GV7 FM0 when service is up-to-date.

&nbsp; - Writes 2 to GV7 FM0 when service is due soon (≤ 10 days / flights).

&nbsp; - Writes 1 to GV7 FM0 when service is overdue.

&nbsp; - This allows logical switches and special functions to react to service state (e.g. automatic page load, sound alerts, haptic warnings, etc.).

&nbsp;   

\- Flexible Options:

&nbsp; - Up to 4 parameters can be used to select which checklist items are displayed.

&nbsp; - A single Interval option is used for both modes:

&nbsp;   - Days in Date Mode

&nbsp;   - Flights in Flight Count Mode

&nbsp; - A shared Last Service field is used:

&nbsp;   - Date (DD/MM/YYYY) in Date Mode

&nbsp;   - Flight count in Flight Count Mode

&nbsp;     

\- Error Handling Messages:

&nbsp; - Congratulations Message:

&nbsp;   - When a valid new service date or flight count is entered that is greater than the previous value and not in the future, a green “Congratulations! Service Complete” message is displayed.

&nbsp; - Future Entry Warnings:

&nbsp;   - If a date entered is later than today, a red “Date Entered Is In The Future” message is displayed.

&nbsp;   - If a flight count entered is greater than the current flight counter, a red “Flight Count Is In The Future” message is displayed.

&nbsp; - Incorrect Entry Errors:

&nbsp;   - If a date entered is earlier than the previous last service date, a red “Date Entered Is Less Than Previous” message is displayed.

&nbsp;   - If a flight count entered is less than the previous last service flight count, a red “Flight Count Is Less Than Previous” message is displayed.

&nbsp; - Messages appear for a short duration, ensuring visibility without interfering with the main display.



\- Date Handling:

&nbsp; - Handles leap years, month lengths, and accurate date math when calculating service due dates.



Notes

\- Designed for EdgeTX 2.11+.

\- Only tracks mechanical service items; batteries and electronics are excluded.

\- Flight counting itself is external to the widget and is typically handled via logical switches and special functions; the widget only reads the selected counter source.

\- Does not modify screen layout; all text positions remain fixed for readability.

\- Flashing title and overdue highlighting can be customized in the code (flash rate, colors).

\- GV7 FM0 integration allows seamless automation with logical switches and special functions.



License

This project is licensed under the Creative Commons

Attribution-NonCommercial 4.0 International License.

Commercial use is not permitted.

